from flask import Flask, request, jsonify
from flask_cors import CORS
import csv

app = Flask(__name__)
CORS(app, resources={r"/chatbot": {"origins": "*"}}, supports_credentials=True)

severityDictionary = {}
description_list = {}
precautionDictionary = {}

def load_data():
    global severityDictionary, description_list, precautionDictionary
    try:
        with open('MasterData/symptom_severity.csv') as severity_file:
            severity_reader = csv.reader(severity_file)
            severityDictionary = {row[0]: int(row[1]) for row_num, row in enumerate(severity_reader, 1) if len(row) >= 2}

        with open('MasterData/dataset.csv') as description_file:
            description_reader = csv.reader(description_file)
            description_list = {row[0]: row[1] for row_num, row in enumerate(description_reader, 1) if len(row) >= 2}

        with open('MasterData/symptom_precaution.csv') as precaution_file:
            precaution_reader = csv.reader(precaution_file)
            precautionDictionary = {row[0]: [row[1], row[2], row[3], row[4]] for row_num, row in enumerate(precaution_reader, 1) if len(row) >= 5}

        print("Description List:", description_list)  # Add this line for debugging

    except FileNotFoundError as e:
        print("Error loading data:", e)
    except Exception as e:
        print("Error:", e)

@app.route('/chatbot', methods=['POST'])
def chatbot():
    user_input = request.json.get('user_input')
    response = process_user_input(user_input)
    return jsonify({'response': response})

def process_user_input(user_input):
    global severityDictionary, description_list, precautionDictionary
    response = ""

    if user_input in severityDictionary:
        severity = severityDictionary[user_input]
        response = f"Severity: {severity}"

        if user_input in description_list:
            response += f"\nDescription: {description_list[user_input]}"

        if user_input in precautionDictionary:
            response += "\nPrecautions:"
            for precaution in precautionDictionary[user_input]:
                response += f"\n- {precaution}"

    else:
        response = "Symptom not found in the database."

    return response

if __name__ == '__main__':
    load_data()
    app.run(debug=True)