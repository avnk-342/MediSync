document.addEventListener('DOMContentLoaded', function() {
    const chatBox = document.getElementById('chat-box');
    const userInput = document.getElementById('user-input');
    const sendBtn = document.getElementById('send-btn');

    sendBtn.addEventListener('click', sendMessage);

    function sendMessage() {
        const message = userInput.value.trim();
        if (message === '') return;

        appendMessage('You', message);

        // Make a POST request to the chatbot API
        fetchChatbotResponse(message)
            .then(response => response.json())
            .then(data => {
                const botResponse = data.response;
                appendMessage('Bot', botResponse);
            })
            .catch(error => {
                console.error('Error:', error);
                appendMessage('Bot', 'Sorry, something went wrong.');
            });

        userInput.value = '';
    }

    function fetchChatbotResponse(message) {
        return fetch('http://localhost:5000/chatbot', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ user_input: message })
        });
    }

    function appendMessage(sender, message) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message', sender.toLowerCase());
        messageElement.textContent = `${sender}: ${message}`;
        chatBox.appendChild(messageElement);
        chatBox.scrollTop = chatBox.scrollHeight;
    }
});
