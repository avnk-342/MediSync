# healthcare-chatbot
a chatbot based on sklearn where you can give a symptom and it will ask you questions and will tell you the details and give some advice.
